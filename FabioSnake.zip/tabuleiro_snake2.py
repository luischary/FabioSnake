#posicoes com 0 significam espacos em branco
#posicoes com 1 significam a cobra
#posicoes com 2 significam a cabeca da cobra
#posicoes com 3 significam a recompensa


import random
from populacao2 import Populacao

class TabuleiroSnake2:

    def __init__(self, largura, altura, unidade):
        #print('inicia tabuleiro')

        self.tab = []
        self.cobra = []
        self.flagRecompensa = False
        self.flagPerdeu = False
        self.step_pontos = 4
        self.contagem_steps_recompensa = 0
        self.pontos = 0
        self.elosCobra = 1
        self.mudancas_de_direcao = 0

        self.passos = 0

        self.linha = 0
        self.coluna = 0

        self.unidade = round(unidade,0)
        self.alturaPixels = unidade * altura
        self.larguraPixels = unidade * largura

        self.largura = largura
        self.altura = altura

        self.recompensaLinha = -1
        self.recompensaColuna = -1

        self.direcao_para_baixo = 33
        self.direcao_para_cima = 44
        self.direcao_para_direita = 55
        self.direcao_para_esquerda = 66

        self.direcao_atual = self.direcao_para_baixo

        

        for linha in range(self.altura):
            temp = []
            for coluna in range(self.largura):
                temp.append(0)
            self.tab.append(temp)

        #coloca a cobra na posicao inicial
        self.iniciaCobra()

        #coloca a primeira recompensa
        self.geraRecompensa()

        #print('limites do tabuleiro ', len(self.tab))
        #print(len(self.tab[0]))


    def geraRecompensa(self):
        #print('gera recompensa')

        colocou = False
        while colocou == False:

            linha = random.randint(0, self.altura - 1)
            coluna = random.randint(0, self.largura - 1)
            #print('coordenadas recompensa ', linha, coluna)


            if self.tab[linha][coluna] == 0:
                self.recompensaLinha = linha
                self.recompensaColuna = coluna

                self.tab[linha][coluna] = 3

                colocou = True


    def iniciaCobra(self):
        #print('inicia cobra')
        linhaInicio = self.linha
        colunaInicio = self.coluna

        temp = []
        temp.append(linhaInicio)
        temp.append(colunaInicio)
        

        self.cobra.append(temp)

        self.tab[linhaInicio][colunaInicio] = 2   

    def anda(self, direcao=""):
        #print('anda')

        if direcao == "":
            direcao = self.direcao_atual
        else:
            if self.direcao_atual != direcao:
                self.mudancas_de_direcao += 1

            self.direcao_atual = direcao

        novaLinha = self.linha
        novaColuna = self.coluna

        if direcao == self.direcao_para_baixo:
            novaLinha += 1
        elif direcao == self.direcao_para_cima:
            novaLinha -= 1
        elif direcao == self.direcao_para_direita:
            novaColuna += 1
        elif direcao == self.direcao_para_esquerda:
            novaColuna -= 1

        #atualiza o objeto
        self.linha = novaLinha
        self.coluna = novaColuna

        #adiciona na cobra
        temp = []
        temp.append(novaLinha)
        temp.append(novaColuna)

        self.cobra.append(temp)

        if self.flagRecompensa == False:
            #retira a primeira posicao
            self.cobra.pop(0)
        else:
            #pegou a recompensa
            if self.contagem_steps_recompensa == self.step_pontos:
                self.flagRecompensa = False
                self.geraRecompensa()
                self.pontos += self.step_pontos
                self.elosCobra += self.step_pontos
                self.contagem_steps_recompensa = 0
            else:
                self.contagem_steps_recompensa += 1

        #atualiza o tabuleiro
        self.atualizaCobraTabuleiro()

        #adiciona contagem de passos
        self.passos += 1
        

    def atualizaCobraTabuleiro(self):
        #print('atualiza cobra no tabuleiro')
        # print(self.cobra)

        #retira a cobra do tabuleiro
        for linha in range(0, self.altura):
            for coluna in range(0, self.largura):
                if self.tab[linha][coluna] == 1 or self.tab[linha][coluna] == 2:
                    self.tab[linha][coluna] = 0

        #verifica se a nova posicao da cobra não execede os limites do tabuleiro
        for posicao in self.cobra:
            linha = posicao[0]
            coluna = posicao[1]

            limiteMaxLinha = self.altura - 1
            limiteMinLinha = 0
            limiteMaxColuna = self.largura - 1
            limiteMinColuna = 0

            if linha > limiteMaxLinha or linha < limiteMinLinha or coluna > limiteMaxColuna or coluna < limiteMinColuna:
                self.flagPerdeu = True
                return 0

        #coloca a cobra
        for posicao in self.cobra:
            #verifica se não encontrou com a recompensa ou se não bateu
            if self.tab[posicao[0]][posicao[1]] == 0:
                self.tab[posicao[0]][posicao[1]] = 1
            elif self.tab[posicao[0]][posicao[1]] == 3: #encontrou uma recompensa
                self.flagRecompensa = True
                self.tab[posicao[0]][posicao[1]] = 1
            elif self.tab[posicao[0]][posicao[1]] == 1 or self.tab[posicao[0]][posicao[1]] == 2: #bateu nela mesma
                self.tab[posicao[0]][posicao[1]] = 1
                self.flagPerdeu = True


    def getCoordenadasCobra(self):
        return self.linha, self.coluna

    def getValorCoordenadas(self, coluna, linha):
        limiteMaxLinha = self.altura - 1
        limiteMinLinha = 0
        limiteMaxColuna = self.largura - 1
        limiteMinColuna = 0

        if linha > limiteMaxLinha or linha < limiteMinLinha or coluna > limiteMaxColuna or coluna < limiteMinColuna:
            return -1
            
        
        return self.tab[linha][coluna]

    def getFitness(self):
        if self.mudancas_de_direcao > 1:
            return (self.pontos*1000)/self.mudancas_de_direcao*self.passos/10
        else:
            return 0



######### FUNCOES DE GERACAO DE VARIAVEIS PARA OS MODELOS ###############

    def getDirecoesGlobais(self):
        direita = 0
        esquerda = 0
        cima = 0
        baixo = 0

        if self.direcao_atual == self.direcao_para_baixo:
            baixo = 1
        elif self.direcao_atual == self.direcao_para_cima:
            cima = 1
        elif self.direcao_atual == self.direcao_para_direita:
            direita = 1
        else:
            esquerda = 1

        return direita,esquerda,cima,baixo

    def getQuantidadeElos(self):
        qtde_elos = (self.elosCobra)/(self.altura * self.largura)
        return qtde_elos


    def calculaDistanciaPremio(self):
        xCobra, yCobra = self.getCoordenadasCobra()

        x_premio = self.recompensaLinha
        y_premio = self.recompensaColuna

        distancia = abs((x_premio - xCobra)) + abs((y_premio - yCobra))

        #normaliza a distancia dividindo pela maior distancia possivel
        distancia = distancia /((self.altura - 0) + (self.largura - 0))

        return distancia

    def calculaDistanciaFrente(self):
        direcao_atual = self.direcao_atual
        yCobra, xCobra = self.getCoordenadasCobra()

        if direcao_atual == self.direcao_para_baixo or direcao_atual == self.direcao_para_cima:
            total = self.altura - 0

            minhaDistancia = abs(yCobra - self.recompensaLinha)

            return minhaDistancia/total
        else:
            total = self.largura - 0

            minhaDistancia = abs(xCobra - self.recompensaColuna)

            return minhaDistancia/total

    def calculaDistanciaLateral(self, lado):
        alturaTabuleiro = self.largura - 0
        larguraTabuleiro = self.altura - 0

        dir_atual = self.direcao_atual
        yCobra, xCobra = self.getCoordenadasCobra()

        resposta = 0
        if lado == "direito":

            if dir_atual == self.direcao_para_direita:
                resposta = (self.recompensaLinha - yCobra)/alturaTabuleiro
            elif dir_atual == self.direcao_para_esquerda:
                resposta = (yCobra - self.recompensaLinha)/alturaTabuleiro
            elif dir_atual == self.direcao_para_cima:
                resposta = (self.recompensaColuna - xCobra)/larguraTabuleiro
            elif dir_atual == self.direcao_para_baixo:
                resposta = (xCobra - self.recompensaColuna)/larguraTabuleiro
        else:
            if dir_atual == self.direcao_para_direita:
                resposta = (yCobra - self.recompensaLinha)/alturaTabuleiro
            elif dir_atual == self.direcao_para_esquerda:
                resposta = (self.recompensaLinha - yCobra)/alturaTabuleiro
            elif dir_atual == self.direcao_para_cima:
                resposta =  (xCobra - self.recompensaColuna)/larguraTabuleiro
            elif dir_atual == self.direcao_para_baixo:
                resposta = (self.recompensaColuna - xCobra)/larguraTabuleiro

        # print('distancia para o lado ', lado)
        # print('xCobra ', xCobra)
        # print('yCobra ', yCobra)
        # print('linhaRecompensa ', self.recompensaLinha)
        # print('colunaRecompensa ', self.recompensaColuna)
        # print('altura tabuleiro ', self.altura)
        # print('largura tabuleiro ', self.largura)

        return resposta



    def temObstaculoLado(self, step, lado='frente'):
        y_atual, x_atual = self.getCoordenadasCobra()

        direcao = self.direcao_atual

        novo_x = 0
        novo_y = 0

        if lado == 'direito':
            if direcao == self.direcao_para_cima: #olhando para a direita
                novo_x = x_atual + step
                novo_y = y_atual
            elif direcao == self.direcao_para_baixo: #olhando para a esquerda
                novo_x = x_atual - step
                novo_y = y_atual
            elif direcao == self.direcao_para_direita: #olhando para baixo
                novo_x = x_atual
                novo_y = y_atual + step
            elif direcao == self.direcao_para_esquerda: #olhando para cima
                novo_x = x_atual
                novo_y = y_atual - step

        elif lado == 'esquerdo':
            if direcao == self.direcao_para_cima: #olhando para a esquerda
                novo_x = x_atual - step
                novo_y = y_atual
            elif direcao == self.direcao_para_baixo: #olhando para a direita
                novo_x = x_atual + step
                novo_y = y_atual
            elif direcao == self.direcao_para_direita: #olhando para cima
                novo_x = x_atual
                novo_y = y_atual - step
            elif direcao == self.direcao_para_esquerda: #olhando para baixo
                novo_x = x_atual
                novo_y = y_atual + step
        else:
            if direcao == self.direcao_para_cima:
                novo_x = x_atual
                novo_y = y_atual - step
            elif direcao == self.direcao_para_baixo:
                novo_x = x_atual
                novo_y = y_atual + step
            elif direcao == self.direcao_para_direita:
                novo_x = x_atual + step
                novo_y = y_atual
            elif direcao == self.direcao_para_esquerda:
                novo_x = x_atual - step
                novo_y = y_atual

        valor = self.getValorCoordenadas(novo_x, novo_y)
        
        if valor == -1 or valor == 1 or valor == 2:
            return 1
        
        return 0

    def estaNoXDaRecompensa(self):
        yCobra, xCobra = self.getCoordenadasCobra()

        if xCobra == self.recompensaColuna:
            return 1
        else:
            return 0

    def estaNoYDaRecompensa(self):
        yCobra, xCobra = self.getCoordenadasCobra()

        if yCobra == self.recompensaLinha:
            return 1
        else:
            return 0
    
    def distanciaParaParede(self, direcao):
        #calcula a distancia para a parede na direcao especificada

        #if direcao == self.direcao_para_baixo:
        return 0
            
