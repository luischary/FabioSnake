from neural_network import NeuralNetwork
import random
import copy

class GeneticAlgorithm:
    def __init__(self, array_populacao):
        self.array_populacao = array_populacao


    def geraNovaGeracao(self, quantMelhores, quantCross, quantMut, quantNovos):
        #comeca ja com o array dos cinco melhores
        # print('Pega melhores da geracao anterior')
        novaGeracao = self.pegaMelhoresPopulacao(quantMelhores)

        quantidade = len(novaGeracao)
        # print('quantidade nova geracao: ', quantidade)

        #faz crossovers
        # print('faz crossovers')
        for i in range(int(quantCross/2)):
            #sorteia dois caras para fazer o cross
            num1 = random.randint(1, quantidade)
            num2 = num1
            while num1 == num2:
                num2 = random.randint(1, quantidade)
            
            novo1, novo2 = self.crossover(novaGeracao[num1 - 1], novaGeracao[num2 - 1])
            novaGeracao.append(novo1)
            novaGeracao.append(novo2)

        
        #faz as mutacoes
        # print('faz mutacoes')
        for i in range(quantMut):
            num = random.randint(1, quantidade)

            novaGeracao.append(self.mutacao(novaGeracao[num-1]))

        quantidadeCamadas = len(novaGeracao[0].camadas)
        
        #agora só gerar os novos integrantes
        # print('gera novos')
        for i in range(1, quantNovos):
            novaGeracao.append(NeuralNetwork(35, quantidadeCamadas, 3))

        return novaGeracao



    def crossover(self, pop1, pop2):
        # print('CROSSOVER')
        # print(pop1.camadas)
        # print(pop2.camadas)

        resultado1 = copy.deepcopy(pop1)
        resultado2 = copy.deepcopy(pop2)

        #para cada camada 
        for camada in range(len(resultado1.camadas)):
            #para cada neuronio da camada
            #print('camada: ', camada)
            for neuronio in range(len(resultado1.camadas[camada])):
                #para cada conexao
                #print('neuronio: ', neuronio)
                for conexao in range(len(resultado1.camadas[camada][neuronio])):
                    #print('conexao: ', conexao)
                    #sorteia para ver se faz a troca entre eles ou não
                    sorteio = random.randint(1, 2)
                    if sorteio == 1:

                        # print('valor anterior: ', pop1.camadas[camada][neuronio][conexao])
                        # print(pop1.camadas)

                        temp = resultado1.camadas[camada][neuronio][conexao]
                        resultado1.mudaValorCamada(camada, neuronio, conexao, resultado2.camadas[camada][neuronio][conexao])
                        resultado2.mudaValorCamada(camada, neuronio, conexao, temp)
                        #resultado1.camadas[camada][neuronio][conexao] = resultado2.camadas[camada][neuronio][conexao]
                        #resultado2.camadas[camada][neuronio][conexao] = temp

                        # print('novo valor: ', pop1.camadas[camada][neuronio][conexao])
                        # print(pop1.camadas)

        # quantidadeParametros = len(resultado1.parametros)
        # for i in range(quantidadeParametros):
        #     #sorteia pra ver de quem vai vir o parametro
        #     sorteio = random.randint(1, 2)
        #     if sorteio == 1:
        #         temp = resultado1.parametros[i]
        #         resultado1.parametros[i] = resultado2.parametros[i]
        #         resultado2.parametros[i] = temp

            
        # print('camadas crossover')
        # print(pop1.camadas)
        # print(pop2.camadas)
        return resultado1, resultado2


    def mutacao(self, pop1):


        #copia meu cara para não alterar o original
        pop = copy.deepcopy(pop1)

        grandeza = random.random()
        if random.randint(1, 2) == 1:
            grandeza = grandeza * (-1)
        #sorteia um gene para alterar

        #para cada camada 
        for camada in range(len(pop.camadas)):
            #para cada neuronio da camada
            for neuronio in range(len(pop.camadas[camada])):
                #para cada conexao
                for conexao in range(len(pop.camadas[camada][neuronio])):
                    #sorteia para ver se faz a troca entre eles ou não
                    sorteio = random.randint(1, 100)
                    if sorteio <= 2:
                        pop.camadas[camada][neuronio][conexao] += grandeza
                        if pop.camadas[camada][neuronio][conexao] > 1:
                            pop.camadas[camada][neuronio][conexao] = 1
                        elif pop.camadas[camada][neuronio][conexao] < -1:
                            pop.camadas[camada][neuronio][conexao] = -1

        # print('MUTACAO')
        # print(pop.camadas)

        #print(pop.parametros)
        return pop

    def pegaMelhoresParametros(self, quant):
        melhorPop = self.pegaMelhoresPopulacao(quant)

        for pop in melhorPop:
            print("PARAMETROS")
            print(pop.camadas)


    def pegaMelhoresPopulacao(self, quant):
        melhorPopulacao = []

        copiaPopulacao = self.array_populacao.copy()
        quantidadeCamadas = len(copiaPopulacao[0].camadas)
        for j in range(quant):
            melhor = -1
            mPop = NeuralNetwork(35, quantidadeCamadas, 3)
            melhorIndice = -1
            for i in range(len(copiaPopulacao)):
                atual = copiaPopulacao[i]
                if atual.score > melhor:
                    melhor = atual.score
                    melhorIndice = i
                    mPop = atual

            if melhorIndice > -1:
                copiaPopulacao.pop(melhorIndice)
                melhorPopulacao.append(mPop)
        
        #print('MELHORES PARAMETROS')
        #for pop in melhorPopulacao:
            #print(pop.parametros)

        return melhorPopulacao