
class Neuronio:

    def __init__(self):
        self.valor = 0
        
        #array de conexoes. Vai ter o indice da proxima camada com o qual esta conectado e o respectivo valor da conexao
        self.conexoes = []
    
    def conectaNeuronio(self, indiceConexao, valorConexao):
        conexao = [indiceConexao, valorConexao]

        self.conexoes.append(conexao)