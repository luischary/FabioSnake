#variaveis levadas em consideracao

#Quantidade de elos
#visão frente (1 bloco)
#visao lado(1 bloco)
#distancia manhattam para a maçã
#visão frente (2 blocos)
#visão lado (2 blocos)
#se esta no x da recompensa
#se esta no y da recompensa
#esta indo para direita
#esta indo para baixo
#esta indo para esquerda
#esta indo para cima
#distancia lateral para a maça
#distancia da frente para a maça
#delta distancia
#bias1
#bias2
#bias3


#7 variaveis para as direcoes
#mais 3 bias
#mais 11 variaveis de decisao
#mais 1 bias

import random
import numpy as np
import math

class Populacao:
    def __init__(self):
        #inicializa autimaticamente os parametros
        self.parametros = []
        self.randomizaParametros()
        self.maiorScore = 0
        self.score = 0
        self.distancia_direita_anterior = 1
        self.distancia_esquerda_anterior = 1
        self.distancia_frente_anterior = 1

    def atualizaScore(self, score):       
        self.score = score

    def sigmoid(self, gamma):
        if gamma > 0:
            divisao = np.exp((-1)*gamma)
            if divisao == (-1):
                divisao == -0.99

            return 1 / (1 + divisao)
        else:
            #divisao = (-1) * np.exp(gamma)
            divisao = np.exp((-1)*gamma)
            if divisao == -1:
                divisao = -0.99
            return 1 / (1 + divisao)

    #retorna zero se não for para mexer, 1 direita, 2 esquerda
    def tomaDecisao(self, tabuleiro): 

        vd = self.sigmoid(self.valorDireita(tabuleiro))
        ve = self.sigmoid(self.valorEsquerda(tabuleiro))
        vf = self.sigmoid(self.valorReto(tabuleiro))

        qtde_elos = (tabuleiro.elosCobra)/(tabuleiro.altura * tabuleiro.largura)
        distancia = self.calculaDistanciaPremio(tabuleiro)
        x_da_recompensa = self.estaNoXDaRecompensa(tabuleiro)
        y_da_recompensa = self.estaNoYDaRecompensa(tabuleiro)
        direita, baixo, esquerda, cima = self.qualDirecaoEstaIndo(tabuleiro)
        #direita_, baixo_, esquerda_, cima_ = self.qualDirecaoRecompensa(tabuleiro)
        

        # print('Variaveis decisao')
        # print('Modelo direita: ', vd)
        # print('Modelo esquerda: ', ve)
        # print('Modelo frente: ', vf)
        # print('qtde_elos: ', qtde_elos)
        # print('distancia premio: ', distancia)
        # print('Esta x da recompensa: ', x_da_recompensa)
        # print('Estan y da recompensa: ', y_da_recompensa)
        # print('direita: ', direita)
        # print('esquerda: ', esquerda)
        # print('cima: ', cima)
        # print('baixo: ', baixo)

        variaveis = []
        variaveis.append(vd)
        variaveis.append(ve)
        variaveis.append(vf)
        variaveis.append(qtde_elos)
        variaveis.append(distancia)
        variaveis.append(x_da_recompensa)
        variaveis.append(y_da_recompensa)
        variaveis.append(direita)
        variaveis.append(esquerda)
        variaveis.append(cima)
        variaveis.append(baixo)

        valor = 0
        #multiplica
        for var, par in zip(variaveis, self.parametros[7:17]):
            valor = valor + (var * par)
        
        #faz o ultimo bias
        valor = valor + self.parametros[-4]
        #passa no sigmoid
        valor_final = self.sigmoid(valor)

        if valor_final <= 0.33:
            return 1
        elif valor_final <= 0.66:
            return 0
        else:
            return 2
        
    def qualDirecaoRecompensa(self, tabuleiro):
        direita = 0
        baixo = 0
        esquerda = 0
        cima = 0

        distanciaFrente = self.calculaDistanciaFrente(tabuleiro)
        distanciaDireita = self.calculaDistanciaLateral(tabuleiro, 'direito')
        distanciaEsquerda = self.calculaDistanciaLateral(tabuleiro, 'esquerdo')



    def qualDirecaoEstaIndo(self, tabuleiro):
        direita = 0
        baixo = 0
        esquerda = 0
        cima = 0

        if tabuleiro.direcao_atual == tabuleiro.direcao_para_baixo:
            baixo = 1
        elif tabuleiro.direcao_atual == tabuleiro.direcao_para_esquerda:
            esquerda = 1
        elif tabuleiro.direcao_atual == tabuleiro.direcao_para_cima:
            cima = 1
        else:
            direita = 1

        return direita, baixo, esquerda, cima

    def valorReto(self, tabuleiro):
        
        visao_1 = self.temObstaculoLado(1, tabuleiro, 'frente')
        visao_2 = self.temObstaculoLado(2, tabuleiro, 'frente')
        visao_3 = self.temObstaculoLado(3, tabuleiro, 'frente')
        visao_4 = self.temObstaculoLado(4, tabuleiro, 'frente')
        visao_5 = self.temObstaculoLado(5, tabuleiro, 'frente')
        distancia_premio = self.calculaDistanciaFrente(tabuleiro)
        delta_distancia = 0
        if self.distancia_frente_anterior != 1:
            delta_distancia = distancia_premio - self.distancia_frente_anterior
            self.distancia_frente_anterior = distancia_premio
        else:
            delta_distancia = distancia_premio
            self.distancia_frente_anterior = distancia_premio

        # print('Variaveis RETO')
        # print('visao 1: ', visao_1)
        # print('visao 2: ', visao_2)
        # print('visao 3: ', visao_3)
        # print('distancia premio: ', distancia_premio)

        self.variaveis = []
        self.variaveis.append(visao_1)
        self.variaveis.append(visao_2)
        self.variaveis.append(visao_3)
        self.variaveis.append(visao_4)
        self.variaveis.append(visao_5)
        self.variaveis.append(distancia_premio)
        self.variaveis.append(delta_distancia)
        
        valor = 0
        somaParametros = 0
        
        for var, par in zip(self.variaveis, self.parametros[:3]):
            #print('var ', var, '    par ', par)
            valor = valor + var * par
            somaParametros += par

        #faz o bias separadamente
        bias = self.parametros[-1]
        valor = valor + bias

        return valor


    def valorDireita(self, tabuleiro):
        
        visao_1 = self.temObstaculoLado(1, tabuleiro, 'direito')
        visao_2 = self.temObstaculoLado(2, tabuleiro, 'direito')
        visao_3 = self.temObstaculoLado(3, tabuleiro, 'direito')
        visao_4 = self.temObstaculoLado(4, tabuleiro, 'direito')
        visao_5 = self.temObstaculoLado(5, tabuleiro, 'direito')
        distancia_premio = self.calculaDistanciaLateral(tabuleiro, 'direito')
        delta_distancia = 0
        if self.distancia_direita_anterior != 1:
            delta_distancia = distancia_premio - self.distancia_direita_anterior
            self.distancia_direita_anterior = distancia_premio
        else:
            delta_distancia = distancia_premio
            self.distancia_direita_anterior = distancia_premio

        # print('Variaveis DIREITA')
        # print('visao 1: ', visao_1)
        # print('visao 2: ', visao_2)
        # print('visao 3: ', visao_3)
        # print('distancia premio: ', distancia_premio)


        self.variaveis = []
        self.variaveis.append(visao_1)
        self.variaveis.append(visao_2)
        self.variaveis.append(visao_3)
        self.variaveis.append(visao_4)
        self.variaveis.append(visao_5)
        self.variaveis.append(distancia_premio)
        self.variaveis.append(delta_distancia)
        
        valor = 0
        somaParametros = 0
        
        for var, par in zip(self.variaveis, self.parametros[:3]):
            #print('var ', var, '    par ', par)
            valor = valor + var * par
            somaParametros += par

        #faz o bias separadamente
        bias = self.parametros[-2]
        valor = valor + bias

        return valor


    def valorEsquerda(self, tabuleiro):
        
        visao_1 = self.temObstaculoLado(1, tabuleiro, 'esquerdo')
        visao_2 = self.temObstaculoLado(2, tabuleiro, 'esquerdo')
        visao_3 = self.temObstaculoLado(3, tabuleiro, 'esquerdo')
        visao_4 = self.temObstaculoLado(4, tabuleiro, 'esquerdo')
        visao_5 = self.temObstaculoLado(5, tabuleiro, 'esquerdo')
        distancia_premio = self.calculaDistanciaLateral(tabuleiro, 'esquerdo')
        
        delta_distancia = 0
        if self.distancia_esquerda_anterior != 1:
            delta_distancia = distancia_premio - self.distancia_esquerda_anterior
            self.distancia_esquerda_anterior = distancia_premio
        else:
            delta_distancia = distancia_premio
            self.distancia_esquerda_anterior = distancia_premio

        # print('Variaveis ESQUERDA')
        # print('visao 1: ', visao_1)
        # print('visao 2: ', visao_2)
        # print('visao 3: ', visao_3)
        # print('distancia premio: ', distancia_premio)

        self.variaveis = []
        self.variaveis.append(visao_1)
        self.variaveis.append(visao_2)
        self.variaveis.append(visao_3)
        self.variaveis.append(visao_4)
        self.variaveis.append(visao_5)
        self.variaveis.append(distancia_premio)
        self.variaveis.append(delta_distancia)
        
        valor = 0
        somaParametros = 0
        
        for var, par in zip(self.variaveis, self.parametros[:3]):
            #print('var ', var, '    par ', par)
            valor = valor + var * par
            somaParametros += par

        #faz o bias separadamente
        bias = self.parametros[-3]
        valor = valor + bias

        return valor



    def estaNoXDaRecompensa(self, tabuleiro):
        xCobra, yCobra = tabuleiro.getCoordenadasCobra()

        if xCobra == tabuleiro.recompensaLinha:
            return 1
        else:
            return 0

    def estaNoYDaRecompensa(self, tabuleiro):
        xCobra, yCobra = tabuleiro.getCoordenadasCobra()

        if yCobra == tabuleiro.recompensaColuna:
            return 1
        else:
            return 0
    
    def randomizaParametros(self):
        for i in range(22):
            self.parametros.append((random.randint(0, 2000)-1000)/1000)

    
    def calculaDistanciaPremio(self, tabuleiro):
        xCobra, yCobra = tabuleiro.getCoordenadasCobra()

        x_premio = tabuleiro.recompensaLinha
        y_premio = tabuleiro.recompensaColuna

        distancia = abs((x_premio - xCobra)) + abs((y_premio - yCobra))

        #normaliza a distancia dividindo pela maior distancia possivel
        distancia = distancia /((tabuleiro.altura - 0) + (tabuleiro.largura - 0))

        return distancia

    def calculaDistanciaFrente(self, tabuleiro):
        direcao_atual = tabuleiro.direcao_atual
        xCobra, yCobra = tabuleiro.getCoordenadasCobra()

        if direcao_atual == tabuleiro.direcao_para_baixo or direcao_atual == tabuleiro.direcao_para_cima:
            total = tabuleiro.altura - 0

            minhaDistancia = abs(xCobra - tabuleiro.recompensaLinha)

            return minhaDistancia/total
        else:
            total = tabuleiro.largura - 0

            minhaDistancia = abs(yCobra - tabuleiro.recompensaColuna)

            return minhaDistancia/total
        

    def calculaDistanciaLateral(self, tabuleiro, lado):
        alturaTabuleiro = tabuleiro.largura - 0
        larguraTabuleiro = tabuleiro.altura - 0

        dir_atual = tabuleiro.direcao_atual
        xCobra, yCobra = tabuleiro.getCoordenadasCobra()

        if lado == "direito":

            if dir_atual == tabuleiro.direcao_para_direita:
                return (tabuleiro.recompensaLinha - xCobra)/alturaTabuleiro
            elif dir_atual == tabuleiro.direcao_para_esquerda:
                return (xCobra - tabuleiro.recompensaLinha)/alturaTabuleiro
            elif dir_atual == tabuleiro.direcao_para_cima:
                return (tabuleiro.recompensaColuna - yCobra)/larguraTabuleiro
            elif dir_atual == tabuleiro.direcao_para_baixo:
                return (yCobra - tabuleiro.recompensaColuna)/larguraTabuleiro
        else:
            if dir_atual == tabuleiro.direcao_para_direita:
                return (xCobra - tabuleiro.recompensaLinha)/alturaTabuleiro
            elif dir_atual == tabuleiro.direcao_para_esquerda:
                return (tabuleiro.recompensaLinha - xCobra)/alturaTabuleiro
            elif dir_atual == tabuleiro.direcao_para_cima:
                return (yCobra - tabuleiro.recompensaColuna)/larguraTabuleiro
            elif dir_atual == tabuleiro.direcao_para_baixo:
                return (tabuleiro.recompensaColuna - yCobra)/larguraTabuleiro



    def temObstaculoLado(self, step, tabuleiro, lado='frente'):
        x_atual, y_atual = tabuleiro.getCoordenadasCobra()

        direcao = tabuleiro.direcao_atual

        novo_x = 0
        novo_y = 0

        if lado == 'direito':
            if direcao == tabuleiro.direcao_para_cima: #olhando para a direita
                novo_x = x_atual + step
                novo_y = y_atual
            elif direcao == tabuleiro.direcao_para_baixo: #olhando para a esquerda
                novo_x = x_atual - step
                novo_y = y_atual
            elif direcao == tabuleiro.direcao_para_direita: #olhando para baixo
                novo_x = x_atual
                novo_y = y_atual + step
            elif direcao == tabuleiro.direcao_para_esquerda: #olhando para cima
                novo_x = x_atual
                novo_y = y_atual - step

        elif lado == 'esquerdo':
            if direcao == tabuleiro.direcao_para_cima: #olhando para a esquerda
                novo_x = x_atual - step
                novo_y = y_atual
            elif direcao == tabuleiro.direcao_para_baixo: #olhando para a direita
                novo_x = x_atual + step
                novo_y = y_atual
            elif direcao == tabuleiro.direcao_para_direita: #olhando para cima
                novo_x = x_atual
                novo_y = y_atual - step
            elif direcao == tabuleiro.direcao_para_esquerda: #olhando para baixo
                novo_x = x_atual
                novo_y = y_atual + step
        else:
            if direcao == tabuleiro.direcao_para_cima:
                novo_x = x_atual
                novo_y = y_atual - step
            elif direcao == tabuleiro.direcao_para_baixo:
                novo_x = x_atual
                novo_y = y_atual + step
            elif direcao == tabuleiro.direcao_para_direita:
                novo_x = x_atual + step
                novo_y = y_atual
            elif direcao == tabuleiro.direcao_para_esquerda:
                novo_x = x_atual - step
                novo_y = y_atual

        valor = tabuleiro.getValorCoordenadas(novo_x, novo_y)
        
        if valor == -1 or valor == 1 or valor == 2:
            return 1
        
        return 0