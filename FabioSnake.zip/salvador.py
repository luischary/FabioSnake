from neural_network import NeuralNetwork

class Salvador:

    def __init__(self):
        return None

    def escreveMelhores(self, melhores):
        numeroAtual = 1

        for rede in melhores:
            f = open("melhores_" + str(numeroAtual) + ".txt", 'w+')

            #escreve c=camada n=neuronio p=peso v=valor para cada uma das linhas
            
            for camada in range(len(rede.camadas)):
                for neuronio in range(len(rede.camadas[camada])):
                    for ligacao in range(len(rede.camadas[camada][neuronio])):
                        valor = rede.camadas[camada][neuronio][ligacao]
                        f.write('C=' + str(camada) + " N=" + str(neuronio) + " L=" + str(ligacao) + " V=" + str(valor) + "\n")

            f.close()
            numeroAtual += 1

    def resgataMelhores(self, quantidade, quantidadeInput, quantidadeCamadas, quantidadeOutput):
        array_melhores = []
        for i in range(quantidade):
            f = open('melhores_' + str(i + 1) + '.txt', 'r')

            f1 = f.readlines()
            novo = NeuralNetwork(quantidadeInput, quantidadeCamadas, quantidadeOutput)

            for linha in f1:
                camada = self.pegaValorLinha('C=', linha, 'inteiro')
                neuronio = self.pegaValorLinha('N=', linha, 'inteiro')
                ligacao = self.pegaValorLinha('L=', linha, 'inteiro')
                valor = self.pegaValorLinha('V=', linha, 'float')

                novo.camadas[camada][neuronio][ligacao] = valor

            array_melhores.append(novo)

        return array_melhores




    def pegaValorLinha(self, identificador, linha, tipo):
        indice = linha.find(identificador)
        proximo_espaco = linha.find(' ', indice)

        sub_temp = linha[indice+2:proximo_espaco]
        if tipo == 'inteiro':
            return int(sub_temp)
        else:
            return float(sub_temp)

        