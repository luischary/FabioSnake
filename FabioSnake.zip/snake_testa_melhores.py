import pygame
import time
from geneticalgorithm2 import GeneticAlgorithm
from neural_network import NeuralNetwork
from tabuleiro_snake2 import TabuleiroSnake2
from salvador import Salvador

def melhorScore(populacoes):
    melhor = 0
    indice = -1
    quantidade = len(populacoes)
    for i in range(quantidade):
        pop = populacoes[i]
        if pop.score > melhor:
            indice = i
            melhor = pop.score
    
    return populacoes[indice]

def somaPontuacao(populacoes):
    soma = 0
    for pop in populacoes:
        soma = soma + pop.score

    return soma

def somaMacas(populacoes):
    soma = 0
    for pop in populacoes:
        soma = soma + pop.pegadas

    return soma

def atualizaTela(tabuleiro, janela):

    #primeiro printa o fundo por cima
    janela.fill((161, 196, 108))
    
    for linha in range(0, tabuleiro.altura):
        for coluna in range(0, tabuleiro.largura):
            valor = tabuleiro.tab[linha][coluna]
            x = coluna * tabuleiro.unidade
            y = linha * tabuleiro.unidade

            if valor == 2 or valor == 1:
                #printa cobra
                pygame.draw.rect(janela, (255, 0, 0), (x, y, tabuleiro.unidade, tabuleiro.unidade))
            elif valor == 3:
                #printa a recompensa
                pygame.draw.rect(janela, (255, 255, 255), (x, y, tabuleiro.unidade, tabuleiro.unidade))

pygame.init()

largura_jogo = 40
altura_jogo = 25

unidade = 25

window_height = unidade * altura_jogo
window_width = unidade * largura_jogo

win = pygame.display.set_mode((window_width, window_height))

pygame.display.set_caption("Snake2")


def snakeDigitalGame2(pop, tabuleiro):
    
    atualizaTela(tabuleiro, win)
    pontosAtual = tabuleiro.pontos
    passos = 0
    run = True
    while run:
        pygame.time.delay(50)

        for event in pygame.event.get():
            if event.type == pygame.QUIT:
                run = False

        direcao_anterior = tabuleiro.direcao_atual
        direcao = direcao_anterior

        resultado = pop.tomaDecisao(tabuleiro)

        if resultado == 1:
            #vira para a esquerda
            if direcao == tabuleiro.direcao_para_baixo:
                direcao = tabuleiro.direcao_para_direita
            elif direcao == tabuleiro.direcao_para_cima:
                direcao = tabuleiro.direcao_para_esquerda
            elif direcao == tabuleiro.direcao_para_esquerda:
                direcao = tabuleiro.direcao_para_baixo
            else:
                direcao = tabuleiro.direcao_para_cima
        elif resultado == 2:
            #vira para a direita
            if direcao == tabuleiro.direcao_para_baixo:
                direcao = tabuleiro.direcao_para_esquerda
            elif direcao == tabuleiro.direcao_para_cima:
                direcao = tabuleiro.direcao_para_direita
            elif direcao == tabuleiro.direcao_para_esquerda:
                direcao = tabuleiro.direcao_para_cima
            else:
                direcao = tabuleiro.direcao_para_baixo

        # keys = pygame.key.get_pressed()
        # if keys[pygame.K_LEFT]:
        #     if direcao_anterior != tabuleiro.direcao_para_direita:
        #         direcao = tabuleiro.direcao_para_esquerda
            
        # if keys[pygame.K_RIGHT]:
        #     if direcao_anterior != tabuleiro.direcao_para_esquerda:
        #         direcao = tabuleiro.direcao_para_direita

        # if keys[pygame.K_UP]:
        #     if direcao_anterior != tabuleiro.direcao_para_baixo:
        #         direcao = tabuleiro.direcao_para_cima

        # if keys[pygame.K_DOWN]:
        #     if direcao_anterior != tabuleiro.direcao_para_cima:
        #         direcao = tabuleiro.direcao_para_baixo


        tabuleiro.anda(direcao)

        direcao_anterior = direcao

        atualizaTela(tabuleiro, win)

        if tabuleiro.flagPerdeu == True:
            run = False

        pygame.display.update()

        pontosFinal = tabuleiro.pontos
        if pontosFinal == pontosAtual:
            passos += 1
        else:
            passos = 0
            pontosAtual = pontosFinal
            pop.atualizaScore(pontosFinal, tabuleiro.elosCobra-1)

        if passos == 250:
            run = False
    
    return tabuleiro.getFitness(), tabuleiro.elosCobra - 1




print("iA")
#cria a primeira leva de caras
array_populacao = []

largura_jogo = 40
altura_jogo = 25
unidade = 25

quantidadeMelhores = 10

salv = Salvador()
array_populacao = salv.resgataMelhores(quantidadeMelhores, 35, 4, 3)

#ia = GeneticAlgorithm(array_populacao)
#array_populacao = ia.geraNovaGeracao(quantidadeMelhores, 800, 300, 50)

#agora testa cada um deles guardando o score no array de scores

treino = True
numGeracao = 0

print('Comecando o treino')
print(time.strftime("%H:%M:%S"))
while treino:
    numGeracao += 1
    numPop = 1
    #print('Treinando geracao ', geracao)
    for pop in array_populacao:

        tabuleiro = TabuleiroSnake2(largura_jogo, altura_jogo, unidade)
        pontos, pegadas = snakeDigitalGame2(pop, tabuleiro)

        pop.atualizaScore(pontos, pegadas)

        numPop+=1
        
    melhorCobra = melhorScore(array_populacao)

    treino = False

    if treino:
        if melhorCobra.pegadas >= 60 and treino:
            # ia = GeneticAlgorithm(array_populacao)
            # print('Melhor pontuacao: ', melhorCobra.score)
            # print('Pontuação atingida na geração: ', numGeracao)
            # ia.pegaMelhoresParametros(5)
            ia = GeneticAlgorithm(array_populacao)
            #pega e salva os melhores
            melhores = ia.pegaMelhoresPopulacao(quantidadeMelhores)
            salv.escreveMelhores(melhores)
            print('terminou')
            treino = False
        else:
            print(time.strftime("%H:%M:%S"))
            print("Resultado geracao %i: %8.2f pontos.Pegou: %i macas. Média: %3.2f pontos"% (numGeracao, melhorCobra.score, melhorCobra.pegadas, somaMacas(array_populacao)/len(array_populacao)))
            # print("Resultado geracao %i", numGeracao, ": ", melhorCobra.score, " pontos. Somou: ", somaPontuacao(array_populacao), " pontos")

            ia = GeneticAlgorithm(array_populacao)
            #pega e salva os melhores
            melhores = ia.pegaMelhoresPopulacao(quantidadeMelhores)
            salv.escreveMelhores(melhores)

            array_populacao = ia.geraNovaGeracao(quantidadeMelhores, 800, 300, 50)

pygame.quit()
