
import random
import numpy as np
from tabuleiro_snake2 import TabuleiroSnake2
from neuronio import Neuronio

class NeuralNetwork:

    def __init__(self, quantInput, quantCamadas, quantOutputs):
        #cria as camadas
        self.camadas = []
        self.quantCamadas = quantCamadas
        self.quantInput = quantInput
        self.quantOutput = quantOutputs
        self.pegadas = 0
        self.score = 0

        #adiciona as camadas
        for i in range(self.quantCamadas):
            self.adicionaCamada(self.quantInput)

        #adiciona output
        self.adicionaCamada(self.quantOutput)

    def atualizaScore(self, score, pegadas):
        self.score = score
        self.pegadas = pegadas

    def tomaDecisao(self, tabuleiro):
        array_input = self.geraArrayInput(tabuleiro)

        resultado = self.predict(array_input)

        # print('resultado')
        # print(resultado)

        esquerda = resultado[0]
        direita = resultado[2]
        frente = resultado[1]

        if esquerda > direita:
            if esquerda > frente:
                return 1
            else:
                return 0
        elif direita > frente:
            return 2
        else:
            return 0

        # maior = max(resultado)
        # if maior == esquerda:
        #     return 1
        # elif maior == direita:
        #     return 2
        # else:
        #     return 0 

    def geraArrayInput(self, tabuleiro):
        #usa o tabuleiro para gerar o array de inputs com as variaveis mais importantes
        
        #direcao atual
        direita,esquerda,cima,baixo = tabuleiro.getDirecoesGlobais()

        quantidade_elos = tabuleiro.getQuantidadeElos()

        esta_x_recompensa = tabuleiro.estaNoXDaRecompensa()
        esta_y_recompensa = tabuleiro.estaNoYDaRecompensa()

        distancia_premio = tabuleiro.calculaDistanciaPremio()
        distancia_frente = tabuleiro.calculaDistanciaFrente()
        distancia_esquerda = tabuleiro.calculaDistanciaLateral('esquerdo')
        distancia_direita = tabuleiro.calculaDistanciaLateral('direito')

        #visoes
        visao_frente_1 = tabuleiro.temObstaculoLado(1, 'frente')
        visao_frente_2 = tabuleiro.temObstaculoLado(2, 'frente')
        visao_frente_3 = tabuleiro.temObstaculoLado(3, 'frente')
        visao_frente_4 = tabuleiro.temObstaculoLado(4, 'frente')
        visao_frente_5 = tabuleiro.temObstaculoLado(5, 'frente')
        visao_frente_6 = tabuleiro.temObstaculoLado(6, 'frente')
        visao_frente_7 = tabuleiro.temObstaculoLado(7, 'frente')
        visao_frente_8 = tabuleiro.temObstaculoLado(8, 'frente')

        visao_esquerda_1 = tabuleiro.temObstaculoLado(1, 'esquerdo')
        visao_esquerda_2 = tabuleiro.temObstaculoLado(2, 'esquerdo')
        visao_esquerda_3 = tabuleiro.temObstaculoLado(3, 'esquerdo')
        visao_esquerda_4 = tabuleiro.temObstaculoLado(4, 'esquerdo')
        visao_esquerda_5 = tabuleiro.temObstaculoLado(5, 'esquerdo')
        visao_esquerda_6 = tabuleiro.temObstaculoLado(6, 'esquerdo')
        visao_esquerda_7 = tabuleiro.temObstaculoLado(7, 'esquerdo')
        visao_esquerda_8 = tabuleiro.temObstaculoLado(8, 'esquerdo')

        visao_direita_1 = tabuleiro.temObstaculoLado(1, 'direito')
        visao_direita_2 = tabuleiro.temObstaculoLado(2, 'direito')
        visao_direita_3 = tabuleiro.temObstaculoLado(3, 'direito')
        visao_direita_4 = tabuleiro.temObstaculoLado(4, 'direito')
        visao_direita_5 = tabuleiro.temObstaculoLado(5, 'direito')
        visao_direita_6 = tabuleiro.temObstaculoLado(6, 'direito')
        visao_direita_7 = tabuleiro.temObstaculoLado(7, 'direito')
        visao_direita_8 = tabuleiro.temObstaculoLado(8, 'direito')


        #coloca todo mundo no array
        a_input = []
        a_input.append(direita)
        a_input.append(esquerda)
        a_input.append(cima)
        a_input.append(baixo)
        a_input.append(quantidade_elos)
        a_input.append(esta_x_recompensa)
        a_input.append(esta_y_recompensa)
        a_input.append(distancia_premio)
        a_input.append(distancia_frente)
        a_input.append(distancia_esquerda)
        a_input.append(distancia_direita)
        a_input.append(visao_frente_1)
        a_input.append(visao_frente_2)
        a_input.append(visao_frente_3)
        a_input.append(visao_frente_4)
        a_input.append(visao_frente_5)
        a_input.append(visao_frente_6)
        a_input.append(visao_frente_7)
        a_input.append(visao_frente_8)
        a_input.append(visao_esquerda_1)
        a_input.append(visao_esquerda_2)
        a_input.append(visao_esquerda_3)
        a_input.append(visao_esquerda_4)
        a_input.append(visao_esquerda_5)
        a_input.append(visao_esquerda_6)
        a_input.append(visao_esquerda_7)
        a_input.append(visao_esquerda_8)
        a_input.append(visao_direita_1)
        a_input.append(visao_direita_2)
        a_input.append(visao_direita_3)
        a_input.append(visao_direita_4)
        a_input.append(visao_direita_5)
        a_input.append(visao_direita_6)
        a_input.append(visao_direita_7)
        a_input.append(visao_direita_8)

        # np.printoptions(precision=3, surpress=True)
        # print('array input')
        # print(a_input)

        return a_input

    def predict(self, array_input):

        multiplicador = array_input
        # print('array input: ')
        # print(array_input)

        for i in range(len(self.camadas)):
            camadaAtual = self.camadas[i]

            novaCamada = []

            # print('camada atual')
            # print(camadaAtual)

            # print('multiplicador')
            # print(multiplicador)
            #para cada neuronio da proxima camada
            for neuronio in camadaAtual:

                # print('neuronio')
                # print(neuronio)

                soma = 0
                #itera por todas as conexoes
                for j in range(len(neuronio)):
                    soma = soma + multiplicador[j] * neuronio[j]

                valorNeuronio = self.funcaoAtivacao(soma)

                # print('valor neuronio')
                # print(valorNeuronio)

                novaCamada.append(valorNeuronio)
            
            multiplicador = novaCamada
        
        return multiplicador

            
    def funcaoAtivacao(self, valor):
        return self.sigmoid(valor)

    def sigmoid(self, gamma):
        if gamma > 0:
            divisao = np.exp((-1)*gamma)
            if divisao == (-1):
                divisao == -0.99

            return 1 / (1 + divisao)
        else:
            #divisao = (-1) * np.exp(gamma)
            divisao = np.exp((-1)*gamma)
            if divisao == -1:
                divisao = -0.99
            return 1 / (1 + divisao)



    def adicionaCamada(self, quantidadeNeuroniosCamada):
        camada = []

        for i in range(quantidadeNeuroniosCamada):
            #para cada neuronio
            neuronio = []
            for j in range(self.quantInput):
                aleatorio  = random.random()
                # aleatorio = random.randint(0, 1)
                #negativo ou positivo?
                if random.randint(1, 2) == 1:
                    aleatorio = aleatorio * (-1)

                neuronio.append(aleatorio)
                # neuronio.append(1)

            camada.append(neuronio)

        self.camadas.append(camada)

    def mudaValorCamada(self, camada, neuronio, conexao, valor):
        self.camadas[camada][neuronio][conexao] = valor
            